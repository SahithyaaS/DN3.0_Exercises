package DependencyInjection;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
