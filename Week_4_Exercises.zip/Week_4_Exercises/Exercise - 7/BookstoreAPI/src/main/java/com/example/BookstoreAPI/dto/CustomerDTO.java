package com.example.BookstoreAPI.dto;

public class CustomerDTO {

}
