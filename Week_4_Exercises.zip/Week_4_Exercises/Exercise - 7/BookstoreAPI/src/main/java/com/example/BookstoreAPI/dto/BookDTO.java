package com.example.BookstoreAPI.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL) // Exclude null fields from the JSON output
public class BookDTO {

    private Long id;

    @JsonProperty("bookTitle") // Rename 'title' to 'bookTitle' in the JSON output
    private String title;

    @JsonProperty("authorName") // Rename 'author' to 'authorName' in the JSON output
    private String author;

    @JsonIgnore // Exclude 'price' from both serialization and deserialization
    private double price;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy") // Format the date in 'dd-MM-yyyy' format
    private Date publicationDate;

    @JsonCreator // Customize how the object is created from JSON
    public BookDTO(
            @JsonProperty("id") Long id,
            @JsonProperty("bookTitle") String title,
            @JsonProperty("authorName") String author,
            @JsonProperty("price") double price,
            @JsonProperty("publicationDate") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy") Date publicationDate) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.publicationDate = publicationDate;
    }
}

