package com.example.BookstoreAPI.exception;

public class BookNotFoundException {

}
