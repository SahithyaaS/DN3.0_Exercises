package com.example.BookstoreAPI.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookstoreAPI.model.Customer;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    @PostMapping("/register")
    public Customer registerCustomer(@RequestBody Customer customer) {
        customers.add(customer);
        return customer;
    }
    public CustomerController() {
        customers.add(new Customer(1L, "Jane Doe", "jane.doe@example.com", "password123", "456 Elm St, Othertown, USA"));
    }
    

    @GetMapping
    public List<Customer> getAllCustomers() {
        return customers;
    }
    @PostMapping("/register-form")
    public Customer registerCustomerForm(@RequestParam Long id,
                                        @RequestParam String name,
                                        @RequestParam String email,
                                        @RequestParam String password,
                                        @RequestParam String address) {
        Customer customer = new Customer(id, name, email, password, address);
        customers.add(customer);
        return customer;
    }


}

