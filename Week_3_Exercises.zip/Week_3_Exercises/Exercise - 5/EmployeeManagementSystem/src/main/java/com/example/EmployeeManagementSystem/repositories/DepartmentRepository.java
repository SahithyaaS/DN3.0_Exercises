package com.example.EmployeeManagementSystem.repositories;
import com.example.EmployeeManagementSystem.entities.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface DepartmentRepository extends JpaRepository<Department, Long> {

     // Use the named query defined in Department entity
    List<Department> findByName(@Param("name") String name);

    // Custom JPQL query using @Query annotation to find departments with a minimum number of employees
    @Query("SELECT d FROM Department d WHERE SIZE(d.employees) >= :minEmployees")
    List<Department> findDepartmentsWithMinEmployees(@Param("minEmployees") int minEmployees);
    
}