package com.example.EmployeeManagementSystem.repositories;

import com.example.EmployeeManagementSystem.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Use the named query defined in Employee entity
    List<Employee> findByDepartmentName(@Param("departmentName") String departmentName);

    // Custom JPQL query using @Query annotation to find employees by email
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    List<Employee> findByEmail(@Param("email") String email);
}


