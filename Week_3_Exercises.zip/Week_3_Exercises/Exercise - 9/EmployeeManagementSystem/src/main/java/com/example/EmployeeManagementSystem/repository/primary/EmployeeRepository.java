package com.example.EmployeeManagementSystem.repository.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagementSystem.entity.primary.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
