package com.example.EmployeeManagementSystem.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.EmployeeManagementSystem.entity.secondary.Department;
import com.example.EmployeeManagementSystem.repository.secondary.DepartmentRepository;
@Service
public class DepartmentService{

    @Autowired
    private DepartmentRepository secondaryEntityRepository;

    public List<Department> getAllSecondaryEntities() {
        return secondaryEntityRepository.findAll();
    }

}

