package com.example.EmployeeManagementSystem.repository.secondary;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagementSystem.entity.secondary.Department;

@Qualifier("secondaryDataSource")
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    
}
