package com.example.EmployeeManagementSystem.projections;

public interface EmployeeNameProjection {

}
