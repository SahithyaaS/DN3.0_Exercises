package com.example.EmployeeManagementSystem.dto;

public class EmployeeDTO {

}
