package com.example.EmployeeManagementSystem.projections;

public class EmployeeCustomProjection {

}
