package com.library.repository;

public class BookRepository {
    // Data access methods
    public void performRepositoryTask() {
        System.out.println("BookRepository is performing a repository task.");
    }
}
