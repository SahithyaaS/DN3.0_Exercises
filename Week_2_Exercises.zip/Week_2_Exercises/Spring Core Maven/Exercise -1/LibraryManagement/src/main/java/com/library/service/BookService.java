package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
    
    public void performService() {
        
    }
}
