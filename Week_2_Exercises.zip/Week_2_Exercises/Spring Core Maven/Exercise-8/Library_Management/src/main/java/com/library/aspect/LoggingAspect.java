package com.library.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    @Before("execution(* com.library.service.BookService.performService(..))")
    public void logBefore() {
        System.out.println("LoggingAspect.logBefore() : BookService.performService() is about to execute.");
    }

    @After("execution(* com.library.service.BookService.performService(..))")
    public void logAfter() {
        System.out.println("LoggingAspect.logAfter() : BookService.performService() has executed.");
    }

    @Around("execution(* com.library.service.BookService.performService(..))")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("LoggingAspect.logAround() : BookService.performService() - before execution.");
        Object result = joinPoint.proceed();
        System.out.println("LoggingAspect.logAround() : BookService.performService() - after execution.");
        return result;
    }
}

