package com.library.repository;

public class BookRepository {
    
    public void performRepositoryTask() {
        
    }
}

