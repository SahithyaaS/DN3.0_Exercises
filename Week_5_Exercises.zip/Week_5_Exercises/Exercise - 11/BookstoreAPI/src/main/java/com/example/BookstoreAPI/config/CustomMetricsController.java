package com.example.BookstoreAPI.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.instrument.MeterRegistry;

@RestController
public class CustomMetricsController {

    @Autowired
    private MeterRegistry meterRegistry;

    @GetMapping("/custom-metrics")
    public String customMetrics() {
        meterRegistry.counter("custom.metric.counter", "type", "example").increment();
        return "Custom metric recorded!";
    }
}

