package com.example.BookstoreAPI.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BookstoreAPI.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
